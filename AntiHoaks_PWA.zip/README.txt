ANTIHOAKS PWA
Cara pemasangan:
1. Upload seluruh isi folder ini ke hosting yang menyediakan HTTPS.
2. Buka URL-nya di Chrome Android.
3. Tekan tombol "Pasang di HP" jika muncul, atau menu Chrome > Tambahkan ke layar utama / Install app.
Catatan: PWA membutuhkan HTTPS (kecuali localhost) agar service worker dapat bekerja.
